
# -*- coding: utf-8 -*-

u'''A pure Python implementation of the 2018 v220627 version of Netherlands' U{RD NAP<https://
www.NSGI.NL/coordinatenstelsels-en-transformaties/coordinatentransformaties/rdnap-etrs89-rdnaptrans>}
specification to convert between GRS80 (ETRS89) geodetic lat-, longitudes and height and local
I{B{R}ijksB{D}riehoeksmeeting (B{RD})} coordinates and I{B{N}ormaal B{A}msterdams B{P}eil (B{NAP})
quasi-geoid-height}.

The results of both B{C{pyrdnap}} transformer classes L{RDNAP2018v1} and L{RDNAP2018v2} have been
formally validated and B{C{PyRDNAP}} has been certified to carry the trademark B{C{RDNAPTRANS(tm)}}.

See module L{pyrdnap.rdnap2018} for further information, usage and implementation details.

See modules L{pyrdnap.v1grid} and L{pyrdnap.v2grid} for the C{RDNAPTRANS(tm)2018_v220627} grid
files, each the original, unmodified ASCII C{.txt} but compressed as C{.txt.zip}.

See function L{pyrdnap.validation3} for C{.../Z001_ETRSandRDNAP.txt} test set details.

See files C{testresults/v1_..._round_trips.txt} for "round-trip" (forward plus reverse) test
results of the L{RDNAP2018v1} transformer, especially the final, summary lines in each file.
'''
import os.path as os_path
import sys

# _isfrozen     = getattr(_sys, 'frozen', False)
pyrdnap_abspath = os_path.dirname(os_path.abspath(__file__))  # _sys._MEIPASS + '/pyrdnap'
_pyrdnap_       = __package__ or  os_path.basename(pyrdnap_abspath)

# setting __path__ should ...
__path__ = [pyrdnap_abspath]
try:  # ... make this import work, ...
    import pyrdnap.__pygeodesy as _  # noqa: F401
except ImportError:  # ... if it doesn't, extend sys.path to include
    # this very directory such that all public and private sub-modules
    # can be imported (by epydoc, checked by PyChecker, etc.)
    if pyrdnap_abspath not in sys.path:
        sys.path.insert(0, pyrdnap_abspath)  # XXX __path__[0]

try:  # PYCHOK pygeodesy
    from pyrdnap.__pygeodesy import *  # noqa: F403
except (AttributeError, ImportError) as x:
    raise AssertionError(str(x))

from pyrdnap.rd0 import *  # noqa: F403
from pyrdnap.rdnap2018 import *  # noqa: F403
from pyrdnap.v_self import *  # noqa: F403


def _all__init__(*names):  # deleted below
    from pyrdnap.__pygeodesy import _all__all__  # PYCHOK ...
    _all__all__.extend(names)
    _all__all__[:] = sorted(_all__all__)  # set(_all__all__)
    return _all__all__


def _versions():  # in .__main__, .v_self, .test/bases
    # Get the pyrdnap, pygeodesy, Python ... versions (C{str}).
    from pyrdnap.__pygeodesy import _SPACE_, _versions as _pygeodesy_versions  # PYCHOK ...
    v  = __version__.replace('.0', '.')
    l_ = [_pyrdnap_, v] + _pygeodesy_versions(None)
    return _SPACE_.join(l_)  # PYCHOK shadows?


__all__ = _all__init__('pyrdnap_abspath')
__version__ = '26.07.09'
# del _all__init__

# **) MIT License
#
# Copyright (C) 2026-2026 -- mrJean1 at Gmail -- All Rights Reserved.
#
# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
# OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
# ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
